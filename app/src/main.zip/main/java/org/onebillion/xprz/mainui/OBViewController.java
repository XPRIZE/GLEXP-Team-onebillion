package org.onebillion.xprz.mainui;

/**
 * Created by alan on 11/10/15.
 */

        import android.app.Activity;
        import android.graphics.Canvas;
        import android.graphics.PointF;
        import android.graphics.Rect;
        import android.os.Handler;
        import android.os.Looper;
        import android.view.MotionEvent;
        import android.view.View;

        import org.onebillion.xprz.utils.OBRunnableSyncUI;


public class OBViewController
{
    public OBView view;
    public Activity activity;
    public boolean inited = false;

    public OBViewController(Activity a)
    {
        activity = a;
    }

    public void viewWasLaidOut(boolean changed, int l, int t, int r, int b)
    {
    }

    public void prepare()
    {
        view.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event)
            {
                if (event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    OBView ov = (OBView)v;
                    ov.controller.touchDownAtPoint(new PointF(event.getX(),event.getY()), ov);
                }
                return true;
            }
        });

    }

    public void start()
    {

    }

    public void drawControls(Canvas canvas)
    {

    }

    public Rect bounds()
    {
        return new Rect(0,0,view.getRight(),view.getBottom());
    }
    public void invalidateView(final Rect r)
    {
        if(Looper.myLooper() == Looper.getMainLooper())
        {
            if (r == null)
                view.invalidate();
            else
                view.invalidate(r);
        }
        else
        {
            new OBRunnableSyncUI(){public void ex()
            {
                invalidateView(r);
            }
            }.run();
        }
    }

    public void invalidateView(int left,int top,int right,int bottom)
    {
        if(Looper.myLooper() == Looper.getMainLooper())
        {
            view.invalidate(left,top,right,bottom);
        }
        else
        {
            final int l=left,t=top,r=right,b=bottom;
			/*new OBRunnableSyncUI(){public void ex()
			{
				invalidateView(l,t,r,b);
			}
			}.run();*/
            new Handler(Looper.getMainLooper()).post(
                    new Runnable() {public void run()
                    {
                        invalidateView(l,t,r,b);
                    }
                    });
        }
    }

    public void touchDownAtPoint(PointF pt, OBView v)
    {

    }
}

