package org.onebillion.xprz.mainui;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.graphics.*;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.*;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageButton;

import org.onebillion.xprz.utils.OB_Maths;
import org.onebillion.xprz.utils.OB_utils;

public class OBMainViewController extends OBViewController
{
    public static final int SHOW_TOP_LEFT_BUTTON = 1,
            SHOW_TOP_RIGHT_BUTTON = 2,
            SHOW_BOTTOM_LEFT_BUTTON = 4,
            SHOW_BOTTOM_RIGHT_BUTTON = 8;
    public List<OBSectionController> viewControllers;
    public ImageButton topLeftButton,topRightButton,bottomLeftButton,bottomRightButton;
    protected Rect _buttonBoxRect = null;
    boolean navigating;

    public OBMainViewController(Activity a)
    {
        super(a);
        viewControllers = new ArrayList<OBSectionController>();
        view = new OBView(a,this);
        ViewGroup rootView = (ViewGroup) a.findViewById(android.R.id.content);
        rootView.addView(view,new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        navigating = false;
    }

    public void addButtons()
    {
        if (topLeftButton != null)
            return;
        View.OnClickListener listener = new View.OnClickListener() {
            public void onClick(View v)
            {
                buttonHit(v);

            }
        };

        Rect bounds = new Rect(0,0,view.getRight(),view.getBottom());
        topLeftButton = OB_utils.buttonFromImageName("backNormal");
        topLeftButton.setOnClickListener(listener);
        PointF pt = OB_Maths.locationForRect(new PointF(0.0419922f, 0.0533854f), bounds);
        view.addSubviewAtPosition(topLeftButton, pt.x, pt.y);
        bottomLeftButton = OB_utils.buttonFromImageName("prevNormal");
        bottomLeftButton.setOnClickListener(listener);
        pt = OB_Maths.locationForRect(new PointF(0.0517578f,0.933594f), bounds);
        view.addSubviewAtPosition(bottomLeftButton, pt.x, pt.y);
        topRightButton = OB_utils.buttonFromImageName("replayAudioNormal");
        topRightButton.setOnClickListener(listener);
        pt = OB_Maths.locationForRect(new PointF(0.947266f,0.0585938f), bounds);
        view.addSubviewAtPosition(topRightButton, pt.x, pt.y);
        bottomRightButton = OB_utils.buttonFromImageName("nextNormal");
        bottomRightButton.setOnClickListener(listener);
        pt = OB_Maths.locationForRect(new PointF(0.948242f,0.933594f), bounds);
        view.addSubviewAtPosition(bottomRightButton, pt.x, pt.y);
    }

    public void buttonHit(View v)
    {
        OBSectionController cont = viewControllers.get(viewControllers.size()-1);
        if (v == topLeftButton)
            cont.exitEvent();
        else if (v == topRightButton)
            cont.replayAudio();
        else if (v == bottomLeftButton)
            cont.prevPage();
        else if (v == bottomRightButton)
            cont.nextPage();
    }

    public void showButtons(int flags)
    {
        if (topLeftButton == null)
            addButtons();
        if ((flags & SHOW_TOP_LEFT_BUTTON)== 0)
            topLeftButton.setAlpha(0.0f);
        else
            topLeftButton.setAlpha(1.0f);
        if ((flags & SHOW_TOP_RIGHT_BUTTON)== 0)
            topRightButton.setAlpha(0.0f);
        else
            topRightButton.setAlpha(1.0f);
        if ((flags & SHOW_BOTTOM_LEFT_BUTTON)== 0)
            bottomLeftButton.setAlpha(0.0f);
        else
            bottomLeftButton.setAlpha(1.0f);
        if ((flags & SHOW_BOTTOM_RIGHT_BUTTON)== 0)
            bottomRightButton.setAlpha(0.0f);
        else
            bottomRightButton.setAlpha(1.0f);
    }

    public void showHideButtons(int flags)
    {
        if (topLeftButton == null)
            addButtons();
        topLeftButton.setVisibility((flags & SHOW_TOP_LEFT_BUTTON)== 0?View.INVISIBLE:View.VISIBLE);
        topRightButton.setVisibility((flags & SHOW_TOP_RIGHT_BUTTON)== 0?View.INVISIBLE:View.VISIBLE);
        bottomLeftButton.setVisibility((flags & SHOW_BOTTOM_LEFT_BUTTON)== 0?View.INVISIBLE:View.VISIBLE);
        bottomRightButton.setVisibility((flags & SHOW_BOTTOM_RIGHT_BUTTON)== 0?View.INVISIBLE:View.VISIBLE);
    }

    public void viewWasLaidOut(boolean changed, int l, int t, int r, int b)
    {
        if (! inited)
        {
            prepare();
            inited = true;
        }
    }

    public void drawControls(Canvas canvas)
    {
        canvas.drawColor(Color.WHITE);
    }

    @Override

    public void prepare()
    {
        addButtons();
        String menuClassName = (String)(MainActivity.mainActivity.Config().get("menuclass"));
        if (menuClassName != null)
            pushViewControllerWithName(menuClassName,false,"menu");
    }

    public void addView(View v)
    {
        if (topLeftButton != null)
        {
            int idx = view.indexOfChild(topLeftButton);
            view.addView(v, idx);
        }
    }

    public void pushViewControllerWithName(String nm,Boolean animate,Object _params)
    {
        try
        {
            Class cnm = Class.forName("org.onebillion.xprz.mainui."+nm);
            pushViewController(cnm, animate, _params);
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    public void pushViewController(Class<?> vcClass,Boolean animate,Object _params)
    {
        Constructor<?> cons;
        OBSectionController controller;
        try
        {
            cons = vcClass.getConstructor();
            controller = (OBSectionController)cons.newInstance();
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return;
        }
        viewControllers.add(controller);
        controller.params = _params;
        OBView v = new OBView(activity, controller);
        v.layout(0, 0, view.getRight(), view.getBottom());
        controller.view = v;
        controller.prepare();
        addView(v);
        showButtons(controller.buttonFlags());
        showHideButtons(controller.buttonFlags());
        final OBSectionController vc = controller;
        new Handler().post(new Runnable()
        {
            @Override
            public void run() {
                vc.start();
            }
        });
    }

    public void animTopView(float horiz,double secs)
    {
        long startms = SystemClock.uptimeMillis();
        double duration = secs*1000f;
        double frac = 0;
        OBViewController topvc = viewControllers.get(viewControllers.size()-1);
        final View v = topvc.view;
        RectF r1 = new RectF(bounds());
        final float left = r1.left-horiz,top = r1.top,right = r1.right-horiz,bottom = r1.bottom;
        while (frac <= 1.0)
        {
            long currtime = SystemClock.uptimeMillis();
            frac = (currtime - startms) / duration;
            double t = OB_Maths.clamp01(frac);
            final float amt = (float) (horiz * t);
            new Handler(Looper.getMainLooper()).post(
                    new Runnable() {public void run()
                    {
                        v.layout((int)(left+amt),(int)top,(int)(right+amt),(int)bottom);
                        v.requestLayout();
                    }
                    });


            try
            {
                Thread.sleep(20);
            }
            catch (InterruptedException e)
            {
            }
        }
    }

    public void pushViewControllerFromRight(Class<?> vcClass,Object _params,boolean fromRight,double duration)
    {
        if (!navigating)
        {
            Constructor<?> cons;
            final OBSectionController controller;
            try
            {
                cons = vcClass.getConstructor(Activity.class);
                controller = (OBSectionController)cons.newInstance(activity);
            }
            catch (Exception e)
            {
                e.printStackTrace();
                return;
            }
            viewControllers.add(controller);
            controller.params = _params;
            final OBView v = new OBView(activity, controller);
            final int vw = view.getRight();
            int vh = view.getBottom();
            int vl;
            if (fromRight)
                vl = vw;
            else
                vl = -vw;
            vl = 0;
            v.layout(vl, 0, vl+vw, vh);
            controller.view = v;
            addView(v);
            controller.prepare();
            showButtons(controller.buttonFlags());
            showHideButtons(controller.buttonFlags());


            if (viewControllers.size() > 2)
            {
                OBSectionController oldvc = viewControllers.get(viewControllers.size()-2);
                view.removeView(oldvc.view);
                viewControllers.remove(viewControllers.size()-2);
            }

            final OBSectionController vc = controller;
            navigating = false;
            new Handler().post(new Runnable()
            {
                @Override
                public void run() {
                    vc.start();
                }
            });

			/*new AsyncTask<Void, Void,Void>()
			{
				protected Void doInBackground(Void... params) {
					animTopView(-vw, 2.0);
					return null;
				}}.execute();
			 */
			/*new Handler().postDelayed(new Runnable()
			{
				@Override
				public void run()
				{
				    TranslateAnimation anim = new TranslateAnimation( 0, -vl , 0, 0 );
				    anim.setDuration(1000);
				    anim.setFillAfter( true );
				    anim.setAnimationListener(new Animation.AnimationListener() {


						@Override
						public void onAnimationEnd(Animation animation) {
							if (viewControllers.size() > 2)
							{
								OBSectionController oldvc = viewControllers.get(viewControllers.size()-2);
								view.removeView(oldvc.view);
								viewControllers.remove(viewControllers.size()-2);
							}

							final OBSectionController vc = controller;
							navigating = false;
							ReadingMainActivity.mainViewController.setPageNo(((RD_ReadingController)controller).pageNo);
							new Handler().post(new Runnable()
							{
								@Override
								public void run() {
									vc.start();
								}
							});

						}

						@Override
						public void onAnimationStart(Animation animation) {
							// TODO Auto-generated method stub

						}

						@Override
						public void onAnimationRepeat(Animation animation) {
							// TODO Auto-generated method stub

						}
					});
				    v.startAnimation(anim);
				}
			},20);

 		*/
        }
    }

    public void popViewController()
    {
        OBSectionController vc  = viewControllers.get(viewControllers.size()-1);
        view.removeView(vc.view);
        viewControllers.remove(viewControllers.size()-1);
        vc  = viewControllers.get(viewControllers.size()-1);
        showButtons(vc.buttonFlags());
        showHideButtons(vc.buttonFlags());
        vc.start();
    }
}
