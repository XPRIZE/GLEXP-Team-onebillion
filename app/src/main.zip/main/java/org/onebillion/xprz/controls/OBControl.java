package org.onebillion.xprz.controls;


        import java.util.ArrayList;
        import java.util.Collections;
        import java.util.HashMap;
        import java.util.List;
        import java.util.Map;

        import android.graphics.*;
        import android.graphics.drawable.BitmapDrawable;
        import android.graphics.drawable.Drawable;

        import org.onebillion.xprz.mainui.MainActivity;
        import org.onebillion.xprz.mainui.OBViewController;
        import org.onebillion.xprz.utils.OBRunnableSyncUI;
        import org.onebillion.xprz.utils.OB_Maths;
        import org.onebillion.xprz.utils.OB_utils;

public class OBControl
{
    public static int LCC_NORMAL = 0,
            LCC_DISABLED = 1,
            LCC_SELECTED = 2;

    public int state;
    public Map<String,Object> settings;
    public Drawable layer;
    public PointF position,anchorPoint;
    public RectF frame,bounds;
    public Boolean hidden,animationsDisabled;
    public long animationKey;
    public Matrix drawMatrix,convertMatrix;
    PointF tempPoint;
    public Bitmap cache;
    public float zPosition,scaleX,scaleY,rotation,borderWidth;
    public OBControl parent;
    public int backgroundColor,highlightColour,borderColour;
    public int tempSortInt;
    public OBControl maskControl;
    public OBStroke stroke;
    public OBViewController controller;
    boolean frameValid;


    public OBControl()
    {
        settings = new HashMap<String, Object>();
        position = new PointF();
        anchorPoint = new PointF(0.5f,0.5f);
        frame = new RectF();
        frameValid = false;
        bounds = new RectF();
        tempPoint = new PointF();
        animationsDisabled = false;
        hidden = false;
        drawMatrix = new Matrix();
        convertMatrix = new Matrix();
        scaleX = 1;
        scaleY = 1;
        zPosition = 0;
        backgroundColor = 0;
        highlightColour = 0;
        borderWidth = 0;
        borderColour = 0;
        setOpacity(1);
    }

    public void enable()
    {
        state = LCC_NORMAL;
    }

    public boolean isEnabled()
    {
        return (state == LCC_NORMAL);
    }

    public void disable()
    {
        state = LCC_DISABLED;
    }

    public void select()
    {
        state = LCC_SELECTED;
    }

    public float opacity()
    {
        if (layer != null)
            return layer.getAlpha() /  255f;
        return 0.0f;
    }

    public void setOpacity(float f)
    {
        if (layer != null)
            layer.setAlpha(Math.round(f*255f));
    }

    public RectF bounds()
    {
        bounds.set(layer.getBounds());
        return bounds;
    }

    public RectF frame()
    {
        frame.set(bounds());
        Matrix m = matrixForBackwardConvert();
        m.mapRect(frame);
        frameValid = true;
        return frame;
    }

    public void setFrame(RectF f)
    {
        if (f != frame)
            frame.set(f);
        position.set(OB_Maths.midPoint(frame));
        if (layer != null)
        {
            layer.setBounds(0, 0, (int) (f.right - f.left), (int) (f.bottom - f.top));
        }
    }

    public void setFrame(float left,float top,float right,float bottom)
    {
        frame.left = left;
        frame.top = top;
        frame.right = right;
        frame.bottom = bottom;
        setFrame(frame);
    }

    public PointF position()
    {
        return position;
    }

    public void setPosition(PointF pt)
    {
        setPosition(pt.x, pt.y);
    }
    public void setPosition(final float x,final float y)
    {
        if (position.x != x || position.y != y)
        {
            new OBRunnableSyncUI()
            {
                public void ex()
                {
                    invalidate();
                    position.set(x, y);
                    frameValid = false;
                    invalidate();
                }
            }.run();
         }
    }

    public void setRight(float rt)
    {
        frame();
        float diff = rt - frame.right;
        setPosition(position.x + diff, position.y);
    }

    public float right()
    {
        return frame().right;
    }

    public void setLeft(float lt)
    {
        frame();
        float diff = lt - frame.left;
        setPosition(position.x + diff, position.y);
    }

    public float left()
    {
        frame.set(frame());
        return frame.left;
    }

    public void setTop(float tp)
    {
        frame();
        float diff = tp - frame.top;
        setPosition(position.x, diff + position.y);
    }

    public float top()
    {
        return frame().top;
    }

    public void setBottom(float bt)
    {
        frame();
        float diff = bt - frame.bottom;
        setPosition(position.x, diff + position.y);
    }

    public float bottom()
    {
        return frame().bottom;
    }

    public PointF bottomPoint()
    {
        frame();
        return new PointF((frame.left + frame.right) / 2,frame.bottom);
    }

    public PointF bottomRight()
    {
        frame();
        return new PointF(frame.right,frame.bottom);
    }

    public PointF bottomLeft()
    {
        frame();
        return new PointF(frame.left,frame.bottom);
    }

    public PointF topPoint()
    {
        frame();
        return new PointF((frame.left + frame.right) / 2,frame.top);
    }

    public PointF topRight()
    {
        frame();
        return new PointF(frame.right,frame.top);
    }

    public PointF topLeft()
    {
        frame();
        return new PointF(frame.left,frame.top);
    }

    public PointF rightPoint()
    {
        frame();
        return new PointF(frame.right,frame.centerY());
    }

    public PointF leftPoint()
    {
        frame();
        return new PointF(frame.left,frame.centerY());
    }

    public void setScaleX(final float sx)
    {
        if (scaleX != sx)
        {
            new OBRunnableSyncUI()
            {
                public void ex()
                {
                    invalidate();
                    scaleX = sx;
                    frameValid = false;
                    invalidate();
                }
            }.run();
        }
    }

    public void setScaleY(final float sy)
    {
        if (scaleY != sy)
        {
            new OBRunnableSyncUI()
            {
                public void ex()
                {
                    invalidate();
                    scaleY = sy;
                    frameValid = false;
                    invalidate();
                }
            }.run();
        }
    }

    public float scaleX()
    {
        return scaleX;
    }
    public float scaleY()
    {
        return scaleY;
    }
    public float scale()
    {
        return scaleX();
    }
    public void setScale(float sc)
    {
        setScaleX(sc);
        setScaleY(sc);
    }
    public float width()
    {
        frame();
        return frame.width();
    }

    public void setWidth(float w)
    {
        frame();
        float oldwidth = frame.width();
        float ratio = w / oldwidth;
        setScaleX(scaleX * ratio);

    }
    public float height()
    {
        frame();
        return frame.height();
    }

    public void setHeight(float h)
    {
        frame();
        float oldHeight = frame.height();
        float ratio = h / oldHeight;
        setScaleY(scaleY * ratio);

    }

    public void pointAt(PointF pt)
    {
        PointF p = OB_Maths.DiffPoints(pt, position);
        float ang = (float)Math.atan2(p.x, -p.y);
        setRotation(ang);
    }

    public void drawLayer(Canvas canvas)
    {
        if (layer != null)
        {
            if (highlightColour != 0)
            {
                layer.setColorFilter(highlightColour, PorterDuff.Mode.SRC_ATOP);
            }

            layer.draw(canvas);
        }
    }

    public Matrix matrixForDraw()
    {
        drawMatrix.reset();
        float ax = anchorPoint.x * bounds().width();
        float ay = anchorPoint.y * bounds.height();
        drawMatrix.preTranslate(position.x, position.y);
        if (rotation != 0)
            drawMatrix.preRotate((float) Math.toDegrees(rotation));
        if (scaleX != 1 || scaleY != 1)
            drawMatrix.preScale(scaleX, scaleY);
        drawMatrix.preTranslate(-ax, -ay);
        return drawMatrix;
    }

    public Matrix matrixForPointForwardConvert()
    {
        convertMatrix.reset();
        float ax = anchorPoint.x * bounds().width();
        float ay = anchorPoint.y * bounds.height();
        convertMatrix.postTranslate(-position.x, -position.y);
        if (rotation != 0)
            convertMatrix.postRotate((float) Math.toDegrees(-rotation));
        if (scaleX != 1 || scaleY != 1)
            convertMatrix.postScale(1 / scaleX, 1 / scaleY);
        convertMatrix.postTranslate(ax, ay);
        return convertMatrix;
    }

    public Matrix matrixForPointBackwardConvert()
    {
        convertMatrix.reset();
        float ax = anchorPoint.x * bounds().width();
        float ay = anchorPoint.y * bounds.height();
        convertMatrix.postTranslate(-ax, -ay);
        if (rotation != 0)
            convertMatrix.postRotate((float) Math.toDegrees(rotation));
        if (scaleX != 1 || scaleY != 1)
            convertMatrix.postScale(scaleX, scaleY);
        convertMatrix.postTranslate(position.x, position.y);
        return convertMatrix;
    }

    public Matrix matrixForForwardConvert()
    {
        //return matrixForPointBackwardConvert();

        convertMatrix.reset();
        float ax = anchorPoint.x * bounds().width();
        float ay = anchorPoint.y * bounds.height();
        convertMatrix.preTranslate(-position.x, -position.y);
        if (rotation != 0)
            convertMatrix.preRotate((float) Math.toDegrees(-rotation));
        if (scaleX != 1 || scaleY != 1)
            convertMatrix.preScale(1 / scaleX, 1 / scaleY);
        convertMatrix.preTranslate(ax, ay);
        return convertMatrix;
    }
    public Matrix matrixForBackwardConvert()
    {
        //return matrixForPointForwardConvert();

        convertMatrix.reset();
        float ax = anchorPoint.x * bounds().width();
        float ay = anchorPoint.y * bounds.height();
        convertMatrix.preTranslate(position.x, position.y);
        //convertMatrix.preTranslate(-ax,-ay);
        if (rotation != 0)
            convertMatrix.preRotate((float)Math.toDegrees(rotation));
        if (scaleX != 1 || scaleY != 1)
            convertMatrix.preScale(scaleX,scaleY);
        //convertMatrix.preTranslate(position.x, position.y);
        convertMatrix.preTranslate(-ax, -ay);
        return convertMatrix;
    }

    public PointF convertPointFromParent(PointF pt)
    {
        Matrix m = matrixForForwardConvert();
        float[] pts = new float[2];
        pts[0] = pt.x;
        pts[1] = pt.y;
        m.mapPoints(pts);
        return new PointF(pts[0],pts[1]);
    }
    public PointF convertPointToParent(PointF pt)
    {
        Matrix m = matrixForBackwardConvert();
        float[] pts = new float[2];
        pts[0] = pt.x;
        pts[1] = pt.y;
        m.mapPoints(pts);
        return new PointF(pts[0],pts[1]);
    }

    public List<OBControl>controlsToAncestor(OBControl ancestor)
    {
        List<OBControl> alist = new ArrayList<OBControl>();
        OBControl pptr = parent;
        while (pptr != ancestor)
        {
            if (pptr == null)
                return new ArrayList<OBControl>();
            alist.add(pptr);
            pptr = pptr.parent;
        }
        return alist;
    }
    public List<OBControl>controlsToDescendant(OBControl descendant)
    {
        List<OBControl> alist = descendant.controlsToAncestor(this);
        Collections.reverse(alist);
        return alist;
    }

    public OBControl commonParentWith(OBControl l)
    {
        OBControl selfp,p;
        selfp = this;
        p = l;
        List<OBControl> parentSet = new ArrayList<OBControl>();
        while (selfp != null || p != null)
        {
            if (selfp != null)
            {
                if (parentSet.contains(selfp))
                    return selfp;
                parentSet.add(selfp);
                selfp = selfp.parent;
            }
            if (p != null)
            {
                if (parentSet.contains(p))
                    return p;
                parentSet.add(p);
                p = p.parent;
            }
        }
        return null;
    }

    public Matrix matrixForConvertToControl(OBControl c)
    {
        Matrix m = new Matrix();
        if (c == this)
            return m;
        OBControl par = commonParentWith(c);
        if (par != this)
        {
            List<OBControl> alist = controlsToAncestor(par);
            alist.add(0, this);
            for (OBControl ch : alist)
                m.preConcat(ch.matrixForBackwardConvert());
        }
        if (c == null)
            return m;
        List<OBControl> clist = c.controlsToAncestor(par);
        clist.add(0,this);
        Collections.reverse(clist);
        for (OBControl ch : clist)
            m.preConcat(ch.matrixForForwardConvert());
        return m;
    }

    public Matrix matrixToConvertPointToControl(OBControl c)
    {
        Matrix m = new Matrix();
        if (c == this)
            return m;
        OBControl par = commonParentWith(c);
        List<OBControl> alist = controlsToAncestor(par);
        alist.add(0, this);
        for (OBControl ch : alist)
            m.postConcat(ch.matrixForPointBackwardConvert());
        if (par != c)
        {
            List<OBControl> clist = c.controlsToAncestor(par);
            Collections.reverse(clist);
            for (OBControl ch : clist)
                m.postConcat(ch.matrixForPointForwardConvert());
        }
        return m;
    }
    public Matrix matrixToConvertPointFromControl(OBControl c)
    {
        Matrix m = new Matrix();
        if (c == this)
            return m;
        OBControl par = commonParentWith(c);
        if (par != c)
        {
            List<OBControl> clist = c.controlsToAncestor(par);
            clist.add(0,c);
            for (OBControl ch : clist)
                m.postConcat(ch.matrixForPointBackwardConvert());
        }
        List<OBControl> alist = controlsToAncestor(par);
        alist.add(0,this);
        Collections.reverse(alist);
        for (OBControl ch : alist)
            m.postConcat(ch.matrixForPointForwardConvert());
        return m;
    }

    public Matrix matrixForConvertFromControl(OBControl c)
    {
        Matrix m = new Matrix();
        if (c == this)
            return m;
        OBControl par = commonParentWith(c);
        if (par != c)
        {
            List<OBControl> clist = c.controlsToAncestor(par);
            clist.add(0,c);
            for (OBControl ch : clist)
                m.preConcat(ch.matrixForBackwardConvert());
        }
        List<OBControl> alist = controlsToAncestor(par);
        alist.add(0,this);
        Collections.reverse(alist);
        for (OBControl ch : alist)
            m.preConcat(ch.matrixForForwardConvert());
        return m;
    }

    public PointF convertPointToControl(PointF pt,OBControl c)
    {
        Matrix m = matrixToConvertPointToControl(c);
        float[] pts = new float[2];
        pts[0] = pt.x;
        pts[1] = pt.y;
        m.mapPoints(pts);
        return new PointF(pts[0],pts[1]);
    }

    public PointF convertPointFromControl(PointF pt,OBControl c)
    {
        Matrix m = matrixToConvertPointFromControl(c);
        float[] pts = new float[2];
        pts[0] = pt.x;
        pts[1] = pt.y;
        m.mapPoints(pts);
        return new PointF(pts[0],pts[1]);
    }

    public RectF convertRectToControl(RectF r,OBControl c)
    {
        Matrix m = matrixToConvertPointToControl(c);
        RectF nr = new RectF();
        m.mapRect(nr, r);
        return nr;
    }

    public RectF convertRectFromControl(RectF r,OBControl c)
    {
        Matrix m = matrixToConvertPointFromControl(c);
        RectF nr = new RectF();
        m.mapRect(nr, r);
        return nr;
    }

    public boolean intersectsWith(OBControl c)
    {
        OBControl par = commonParentWith(c);
        RectF thisFrame = convertRectToControl(bounds(), par);
        RectF thatFrame = c.convertRectToControl(bounds(),par);
        return RectF.intersects(thisFrame,thatFrame);
    }

    public boolean intersectsWithn(OBControl c)
    {
        RectF thisFrame = convertRectToControl(bounds(), null);
        RectF thatFrame = c.convertRectToControl(bounds(),null);
        if (!thisFrame.intersect(thatFrame))
            return false;
        int w = (int)thisFrame.width();
        int h = (int)thisFrame.height();
        Bitmap tinycache1 = Bitmap.createBitmap(w,h, Bitmap.Config.ARGB_8888);
        Canvas canvas1 = new Canvas(tinycache1);
        canvas1.clipRect(0, 0, w, h);
        canvas1.save();
        canvas1.translate(-thisFrame.left, -thisFrame.top);
        draw(canvas1);
        canvas1.restore();
        Bitmap tinycache2 = Bitmap.createBitmap(w,h, Bitmap.Config.ARGB_8888);
        Canvas canvas2 = new Canvas(tinycache2);
        canvas2.clipRect(0, 0, w, h);
        canvas2.translate(-thisFrame.left, -thisFrame.top);
        c.draw(canvas2);
        Paint p = new Paint();
        p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas1.drawBitmap(tinycache2,0,0,p);
        int pixels[] = new int[w];
        for (int i = 0;i < h;i++)
        {
            tinycache1.getPixels(pixels,0,w,0,i,w,1);
            for (int j = 0;j < w;j++)
            {
                int px = pixels[j] & 0xFF000000;
                if (px != 0)
                    return true;
            }
        }

        return false;
    }

    public Matrix matrixForCacheDraw()
    {
        convertMatrix.reset();
        float ax = anchorPoint.x * bounds().width();
        float ay = anchorPoint.y * bounds.height();
        convertMatrix.preTranslate(ax,ay);
        if (rotation != 0)
            convertMatrix.preRotate(-rotation);
        if (scaleX != 1 || scaleY != 1)
            convertMatrix.preScale(scaleX,scaleY);
        convertMatrix.preTranslate(-ax, -ay);
        return convertMatrix;
    }

    public void drawBorderAndBackground(Canvas canvas)
    {
        if (backgroundColor != 0)
        {
            Paint fillPaint = new Paint();
            int col = OB_utils.applyColourOpacity(backgroundColor,opacity());
            fillPaint.setColor(col);
            fillPaint.setStyle(Paint.Style.FILL);
            canvas.drawRect(bounds(), fillPaint);
        }
        if (borderColour != 0 && borderWidth > 0.0)
        {
            Paint strokePaint = new Paint();
            strokePaint.setStrokeWidth(borderWidth);
            int col = OB_utils.applyColourOpacity(borderColour,opacity());
            strokePaint.setColor(col);
            strokePaint.setStyle(Paint.Style.STROKE);
            canvas.drawRect(bounds(), strokePaint);
        }
    }
    public void draw(Canvas canvas)
    {
        if (!hidden)
        {
            canvas.save();
            if (cache != null)
            {
                canvas.concat(matrixForDraw());
                //canvas.concat(matrixForCacheDraw());
                Paint p = null;
                if (highlightColour != 0)
                {
                    p = new Paint();
                    p.setColorFilter(new PorterDuffColorFilter(highlightColour, PorterDuff.Mode.SRC_ATOP));
                }
                canvas.drawBitmap(cache, 0, 0, p);
            }
            else
            {
                canvas.concat(matrixForDraw());
                drawBorderAndBackground(canvas);
                drawLayer(canvas);
            }
            canvas.restore();
        }
    }

    public void enCache()
    {
        cache = Bitmap.createBitmap((int)(bounds().right - bounds().left),(int)(bounds().bottom - bounds().top), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(cache);
        drawLayer(canvas);
    }

    public Bitmap renderedImage()
    {
        Bitmap bm = Bitmap.createBitmap((int)(frame.right - frame.left),(int)(frame.bottom - frame.top), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bm);
        drawLayer(canvas);
        return bm;
    }

    public OBImage renderedImageControl()
    {
        BitmapDrawable bmd = new BitmapDrawable(MainActivity.mainActivity.getResources(),renderedImage());
        OBImage im = new OBImage(bmd);
        return im;
    }

    public Bitmap renderedImageOverlay(int col)
    {
        Bitmap bm = Bitmap.createBitmap((int)(frame.right - frame.left),(int)(frame.bottom - frame.top), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bm);
        drawLayer(canvas);
        Paint paint = new Paint();
        paint.setColor(col);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
        canvas.drawRect(0,0,(int)(frame.right - frame.left),(int)(frame.bottom - frame.top),paint);
        return bm;
    }


    public void unCache()
    {
        cache = null;
    }
    public void setProperty(String prop,Object val)
    {
        if (val == null)
            settings.remove(prop);
        else
            settings.put(prop, val);
    }

    public Object propertyValue(String prop)
    {
        return settings.get(prop);
    }

    public void show()
    {
        if (hidden)
        {
            new OBRunnableSyncUI()
            {
                public void ex()
                {
                    hidden = false;
                    invalidate();
                }
            }.run();
        }
    }

    public void hide()
    {
        if (!hidden)
        {
            new OBRunnableSyncUI()
            {
                public void ex()
                {
                    invalidate();
                    hidden = true;
                }
            }.run();
        }
    }

    public void setMaskControl(OBControl m)
    {
        maskControl = m;
    }

    public float rotation()
    {
        return rotation;
    }
    public void setRotation(final float rt)
    {
        new OBRunnableSyncUI()
        {
            public void ex()
            {
                invalidate();
                rotation = rt;
                frameValid = false;
                invalidate();
            }
        }.run();
    }
/*
    void move(PointF frompt,PointF topt,double secs,OBSectionController cont)
    {
        long startms = SystemClock.uptimeMillis();
        double duration = secs*1000f;
        double frac = 0;
        RectF r1 = new RectF();
        RectF r2 = new RectF();
        PointF pout = new PointF();
        final OBSectionController fcont = cont;
        while (frac <= 1.0)
        {
            long currtime = SystemClock.uptimeMillis();
            frac = (currtime - startms) / duration;
            double t = OB_Maths.clamp01(frac);
            r1.set(frame());
            OB_Maths.tPointAlongLine((float)t,frompt,topt,pout);
            setPosition(pout);
            r2.set(frame());
            final int rl1 = (int)r1.left,rt1 = (int)r1.top,rr1 = (int)r1.right,rb1 = (int)r1.bottom;
            final int rl2 = (int)r2.left,rt2 = (int)r2.top,rr2 = (int)r2.right,rb2 = (int)r2.bottom;
            fcont.invalidateView(rl1,rt1,rr1,rb1);
            fcont.invalidateView(rl2,rt2,rr2,rb2);
            try
            {
                Thread.sleep(20);
            }
            catch (InterruptedException e)
            {
            }
        }
    }

    public void moveAlongPath(Path path,double secs,boolean wait,OBViewController cont)
    {
        long startms = SystemClock.uptimeMillis();
        double duration = secs*1000f;
        double frac = 0;
        RectF r1 = new RectF();
        RectF r2 = new RectF();
        PointF pout = new PointF();
        final OBViewController fcont = cont;
        while (frac <= 1.0)
        {
            long currtime = SystemClock.uptimeMillis();
            frac = (currtime - startms) / duration;
            double t = OB_Maths.clamp01(frac);
            r1.set(frame());
            setPosition(pout);
            r2.set(frame());
            final int rl1 = (int)r1.left,rt1 = (int)r1.top,rr1 = (int)r1.right,rb1 = (int)r1.bottom;
            final int rl2 = (int)r2.left,rt2 = (int)r2.top,rr2 = (int)r2.right,rb2 = (int)r2.bottom;
            new OBRunnableSyncUI(){public void ex()
            {
                fcont.invalidateView(rl1,rt1,rr1,rb1);
                fcont.invalidateView(rl2,rt2,rr2,rb2);
            }}.run();
            try
            {
                Thread.sleep(20);
            }
            catch (InterruptedException e)
            {
            }
        }
    }
*/
    public boolean containsPoint(PointF pt)
    {
        pt = convertPointFromControl(pt,null);
        return bounds().contains(pt.x, pt.y);
    }

    public void setAnchorPoint(PointF pt)
    {
        anchorPoint.set(pt);
    }

    public void setAnchorPoint(float x,float y)
    {
        anchorPoint.set(x,y);
    }

    public void setShadow(float sradius,float sopacity,float soffsetx,float soffsety,int scolour)
    {

    }

    public void invalidate()
    {
        if (controller == null)
        {
            if (parent != null)
                parent.invalidate();
        }
        else
        {
            final RectF f = frame();
            new OBRunnableSyncUI()
            {
                public void ex()
                {
                    controller.invalidateView((int) f.left, (int) f.top, (int) f.right, (int) f.bottom);
                }
            }.run();
        }
    }
    public void highlight()
    {
        new OBRunnableSyncUI()
        {
            public void ex()
            {
                highlightColour = Color.argb(127, 0, 0, 0);
                invalidate();
            }
        }.run();
    }

    public void lowlight()
    {
        new OBRunnableSyncUI()
        {
            public void ex()
            {
                highlightColour = 0;
                invalidate();
            }
        }.run();
    }

    public int colourAtPoint(float x,float y)
    {
        Bitmap tinycache = Bitmap.createBitmap(1,1, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(tinycache);
        canvas.clipRect(0, 0, 1, 1);
        canvas.translate(-x, -y);
        drawBorderAndBackground(canvas);
        drawLayer(canvas);
        return tinycache.getPixel(0,0);
    }
    public float alphaAtPoint(float x,float y)
    {
        return (Color.alpha(colourAtPoint(x,y))/255f);
    }
}
