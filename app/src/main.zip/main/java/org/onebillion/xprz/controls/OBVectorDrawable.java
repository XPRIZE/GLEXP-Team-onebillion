package org.onebillion.xprz.controls;


import android.graphics.*;
import android.graphics.drawable.Drawable;

import org.onebillion.xprz.utils.OB_utils;

public class OBVectorDrawable extends Drawable
{
    public Path path;
    public Paint fillPaint,strokePaint;
    public OBStroke stroke;
    public int fillColour;
    public float shadowRadius,shadowOffsetX,shadowOffsetY;
    public int shadowColour;
    float opacity;
    Rect bounds;



    public OBVectorDrawable()
    {
        super();
        fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        fillPaint.setStyle(Paint.Style.FILL);
        strokePaint.setStyle(Paint.Style.STROKE);
        opacity = 1;
        stroke = new OBStroke();
    }

    public OBVectorDrawable(Path p)
    {
        this();
        path = p;
    }
    @Override
    public void draw(Canvas canvas)
    {
        if (path != null)
        {
            setUpPaint();
            if (fillColour != 0)
                canvas.drawPath(path, fillPaint);
            if (stroke != null)
                canvas.drawPath(path, strokePaint);
        }
    }

    @Override
    public void setAlpha(int alpha)
    {
        opacity = alpha / 255f;

    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        // TODO Auto-generated method stub

    }

    @Override
    public int getOpacity()
    {
        // TODO Auto-generated method stub
        if (opacity < 1)
            return PixelFormat.TRANSLUCENT;
        return PixelFormat.OPAQUE;
    }

    public void setUpPaint()
    {
        if (stroke != null)
        {
            strokePaint.setStrokeWidth(stroke.lineWidth);
            int col = OB_utils.applyColourOpacity(stroke.colour,opacity);
            strokePaint.setColor(col);
            strokePaint.setStrokeCap(stroke.paintLineCap());
            strokePaint.setStrokeJoin(stroke.paintLineJoin());
            DashPathEffect dpe = stroke.dashPathEffect();
            if (dpe != null)
                strokePaint.setPathEffect(dpe);
            strokePaint.setStyle(Paint.Style.STROKE);
        }
        if (fillColour != 0)
        {
            int col = OB_utils.applyColourOpacity(fillColour,opacity);
            fillPaint.setColor(col);
            //fillPaint.setMaskFilter(new BlurMaskFilter(7, BlurMaskFilter.Blur.NORMAL));
            fillPaint.setShadowLayer(shadowRadius, shadowOffsetX, shadowOffsetY, shadowColour);
            fillPaint.setStyle(Paint.Style.FILL);
        }
    }

    public void setShadow(float radius,float offsetX,float offsetY,int colour)
    {
        shadowRadius = radius;
        shadowOffsetX = offsetX;
        shadowOffsetY = offsetY;
        shadowColour = colour;
    }


}
