package org.onebillion.xprz.controls;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;

/**
 * Created by alan on 12/12/15.
 */
public class OBTextDrawable extends Drawable
{

    public Typeface typeFace;
    public float textSize;
    public String text;
    public int colour;
    public Paint textPaint;
    float lineOffset;
    Rect tempRect;

    public OBTextDrawable(Typeface tf,float size,int col,String s)
    {
        super();
        typeFace = tf;
        textSize = size;
        text = s;
        colour = col;
        textPaint = new Paint();
        tempRect = new Rect();
    }

    @Override
    public void draw(Canvas canvas)
    {
        textPaint.setTextSize(textSize);
        textPaint.setTypeface(typeFace);
        textPaint.setColor(colour);
        textPaint.getTextBounds(text, 0, text.length(), tempRect);
        float textStart = (getBounds().right - tempRect.right) / 2;
        canvas.drawText(text,textStart,lineOffset,textPaint);
    }

    @Override
    public void setAlpha(int alpha) {
        // TODO Auto-generated method stub

    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        // TODO Auto-generated method stub

    }

    @Override
    public int getOpacity() {
        // TODO Auto-generated method stub
        return 0;
    }

    public void calcBounds(Rect bb)
    {
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        float maxAscender = fm.top;
        float maxDescender = fm.bottom;
        lineOffset = -maxAscender;
        textPaint.getTextBounds(text,0,text.length(),bb);
        bb.right = bb.right - bb.left;
        bb.left = 0;
        bb.top = 0;
        bb.bottom = (int)(Math.ceil((double)(maxDescender - maxAscender)));
    }
    public void sizeToBoundingBox()
    {
        Rect b = new Rect();
        textPaint.setTextSize(textSize);
        textPaint.setTypeface(typeFace);
        calcBounds(b);
        setBounds(b);
    }

}
