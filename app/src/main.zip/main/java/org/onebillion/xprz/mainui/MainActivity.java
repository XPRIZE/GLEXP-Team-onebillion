package org.onebillion.xprz.mainui;

import android.graphics.PointF;
import android.graphics.Typeface;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;

import java.io.InputStream;
import java.util.*;

import org.onebillion.xprz.R;
import org.onebillion.xprz.controls.OBControl;
import org.onebillion.xprz.controls.OBGroup;
import org.onebillion.xprz.utils.OBAudioManager;
import org.onebillion.xprz.utils.OBImageManager;
import org.onebillion.xprz.utils.OBUser;
import org.onebillion.xprz.utils.OBXMLManager;
import org.onebillion.xprz.utils.OB_Maths;
import org.onebillion.xprz.utils.OB_utils;

public class MainActivity extends ActionBarActivity
{
    public static String CONFIG_IMAGE_SUFFIX = "image_suffix",
            CONFIG_AUDIO_SUFFIX = "audio_suffix",
            CONFIG_AUDIO_SEARCH_PATH = "audioSearchPath",
            CONFIG_IMAGE_SEARCH_PATH = "imageSearchPath",
            CONFIG_CONFIG_SEARCH_PATH = "configSearchPath",
            CONFIG_LEFT_BUTTON_POS = "lbuttonpos",
            CONFIG_RIGHT_BUTTON_POS = "rbuttonpos",
            CONFIG_GRAPHIC_SCALE = "graphicscale",
            CONFIG_POINTERS = "pointers",
            CONFIG_POINTERCOORDS = "pointercoords",
            CONFIG_POINTERSTARTPOINTS = "pointerstartpoints",
            CONFIG_COLOURS = "colours",
            CONFIG_SKINCOLOURS = "skincolours",
            CONFIG_SKINCOLOUR = "skincolour",
            CONFIG_MENUTABCOLOURS = "menutabcolours",
            CONFIG_LOCKED = "locked",
            CONFIG_LANGUAGE = "language",
            CONFIG_DEFAULT_LANGUAGE = "defaultlanguage",
            CONFIG_CLOTHCOLOUR = "clothcolour",
            CONFIG_VECTOR_SEARCH_PATH = "vectorsearchpath",
            CONFIG_AWARDAUDIO = "staraudio",
            CONFIG_APP_CODE = "app_code",
            CONFIG_USER = "user";
    public static MainActivity mainActivity;
    public static OBMainViewController mainViewController;
    public Map<String, Object> config;
    public List<OBUser>users;
    public static Typeface standardTypeFace;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MainActivity.mainActivity = this;
        users = new ArrayList<OBUser>();
        try
        {
            setUpConfig();
            mainViewController = new OBMainViewController(this);
            new OBAudioManager();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public static OBGroup armPointer()
    {
        OBGroup arm = OBImageManager.sharedImageManager().vectorForName("arm");
        OBControl anchor = arm.objectDict.get("anchor");
        if (anchor != null)
        {
            PointF pt = arm.convertPointFromControl(anchor.position, anchor.parent);
            PointF rpt = OB_Maths.relativePointInRectForLocation(pt, arm.bounds());
            arm.anchorPoint = rpt;
        }
        else
            arm.anchorPoint = new PointF(0.64f, 0);
        int skincol = OB_utils.SkinColour(0);
        arm.substituteFillForAllMembers("skin.*",skincol);
        int clothcol = mainActivity.configIntForKey(CONFIG_CLOTHCOLOUR);
        arm.substituteFillForAllMembers("cloth.*",clothcol);
        //arm.borderColour = 0xff000000;
        //arm.borderWidth = 1;
        return arm;
    }

    public String languageCode()
    {
        return "en_gb";
    }

    OBSectionController topController()
    {
        List l = mainViewController.viewControllers;
        return (OBSectionController) l.get(l.size()-1);
    }

    public static Map<String, Object> Config()
    {
        return mainActivity.config;
    }

    public Object configValueForKey(String k)
    {
        return config.get(k);
    }

    public String configStringForKey(String k)
    {
        return (String)config.get(k);
    }

    public int configIntForKey(String k)
    {
        Integer i = (Integer) config.get(k);
        return i.intValue();
    }
    public float configFloatForKey(String k)
    {
        Float f = (Float) config.get(k);
        return f.floatValue();
    }

    public List<String> audioSearchPath(String appDir,String genDir)
    {
        String wDir = null;
        if (OB_utils.lastPathComponent(OB_utils.stringByDeletingLastPathComponent(appDir)).equals("books"))
            wDir = OB_utils.stringByDeletingLastPathComponent(OB_utils.stringByDeletingLastPathComponent(appDir));
        String language = (String)config.get(CONFIG_LANGUAGE);
        String defaultLanguage = (String)config.get(CONFIG_DEFAULT_LANGUAGE);
        List audioSearchPath = new ArrayList(4);
        if (!language.equals(defaultLanguage))
        {
            if (appDir != null)
                audioSearchPath.add(OB_utils.stringByAppendingPathComponent(OB_utils.stringByAppendingPathComponent(appDir,"local"),language));
            if (wDir != null)
                audioSearchPath.add(OB_utils.stringByAppendingPathComponent(OB_utils.stringByAppendingPathComponent(wDir,"local"),language));
            audioSearchPath.add(OB_utils.stringByAppendingPathComponent(OB_utils.stringByAppendingPathComponent(genDir,"local"),language));
        }
        if (appDir != null)
            audioSearchPath.add(OB_utils.stringByAppendingPathComponent(OB_utils.stringByAppendingPathComponent(appDir,"local"),defaultLanguage));
        if (wDir != null)
            audioSearchPath.add(OB_utils.stringByAppendingPathComponent(OB_utils.stringByAppendingPathComponent(wDir,"local"),defaultLanguage));
        audioSearchPath.add(OB_utils.stringByAppendingPathComponent(OB_utils.stringByAppendingPathComponent(genDir,"local"),defaultLanguage));

        if (appDir != null)
            audioSearchPath.add(OB_utils.stringByAppendingPathComponent(appDir,"sfx"));
        audioSearchPath.add(OB_utils.stringByAppendingPathComponent(genDir,"sfx"));

        for (int i = audioSearchPath.size() - 1;i >= 0;i--)
            if (!OB_utils.assetsDirectoryExists((String)audioSearchPath.get(i)))
                audioSearchPath.remove(i);

        return audioSearchPath;
    }

    public List<String> imageSearchPath(String appDir,String genDir)
    {
        Boolean inBooks = (OB_utils.lastPathComponent(OB_utils.stringByDeletingLastPathComponent(appDir)).equals("books"));
        List lowres = new ArrayList(4);
        if (appDir != null)
        {
            lowres.add(OB_utils.stringByAppendingPathComponent(appDir,"img/shared_3"));
            if (inBooks)
            {
                String wDir = OB_utils.stringByDeletingLastPathComponent(OB_utils.stringByDeletingLastPathComponent(appDir));
                lowres.add(OB_utils.stringByAppendingPathComponent(wDir,"img/shared_3"));
            }
        }
        lowres.add(OB_utils.stringByAppendingPathComponent(genDir,"img/shared_3"));
        List highres = new ArrayList(4);
        if (appDir != null)
        {
            highres.add(OB_utils.stringByAppendingPathComponent(appDir,"img/shared_4"));
            if (inBooks)
            {
                String wDir = OB_utils.stringByDeletingLastPathComponent(OB_utils.stringByDeletingLastPathComponent(appDir));
                highres.add(OB_utils.stringByAppendingPathComponent(wDir,"img/shared_4"));
            }
        }
        highres.add(OB_utils.stringByAppendingPathComponent(genDir,"img/shared_4"));

        List imageSearchPath = new ArrayList(4);
        imageSearchPath.addAll(highres);
        imageSearchPath.addAll(lowres);
        return imageSearchPath;
    }

    public List<String> configSearchPath(String appDir,String genDir)
    {
        List configSearchPath = new ArrayList(4);
        if (appDir != null)
        {
            configSearchPath.add(OB_utils.stringByAppendingPathComponent(appDir,"config"));
            if (OB_utils.lastPathComponent(OB_utils.stringByDeletingLastPathComponent(appDir)).equals("books"))
            {
                String wDir = OB_utils.stringByDeletingLastPathComponent(OB_utils.stringByDeletingLastPathComponent(appDir));
                configSearchPath.add(OB_utils.stringByAppendingPathComponent(wDir,"config"));
            }
        }
        configSearchPath.add(OB_utils.stringByAppendingPathComponent(genDir,"config"));
        return configSearchPath;
    }

    public List<String> vectorSearchPath(String appDir,String genDir)
    {
        List configSearchPath = new ArrayList(4);
        if (appDir != null)
        {
            configSearchPath.add(OB_utils.stringByAppendingPathComponent(appDir,"img/vector"));
            if (OB_utils.lastPathComponent(OB_utils.stringByDeletingLastPathComponent(appDir)).equals("books"))
            {
                String wDir = OB_utils.stringByDeletingLastPathComponent(OB_utils.stringByDeletingLastPathComponent(appDir));
                configSearchPath.add(OB_utils.stringByAppendingPathComponent(wDir,"img/vector"));
            }
        }
        configSearchPath.add(OB_utils.stringByAppendingPathComponent(genDir,"img/vector"));
        return configSearchPath;
    }

    public void updateConfigPaths(String newAppCode,Boolean force)
    {
        String lastAppCode = (String)config.get(CONFIG_APP_CODE);
        if (lastAppCode.equals(newAppCode) && !force)
            return;
        config.put(CONFIG_APP_CODE,newAppCode);
        String appDir = newAppCode;
        String genDir = (String)config.get("gen_code");
        String languageCode = languageCode();
        if (languageCode != null)
            config.put(CONFIG_LANGUAGE,languageCode);
        else
            config.put(CONFIG_LANGUAGE,config.get(CONFIG_DEFAULT_LANGUAGE));
        config.put(CONFIG_AUDIO_SEARCH_PATH,audioSearchPath(appDir,genDir));
        config.put(CONFIG_IMAGE_SEARCH_PATH,imageSearchPath(appDir, genDir));
        config.put(CONFIG_VECTOR_SEARCH_PATH,vectorSearchPath(appDir, genDir));
        config.put(CONFIG_CONFIG_SEARCH_PATH,configSearchPath(appDir, genDir));
    }

    public void setUpConfig() throws Exception
    {
        InputStream pis;
        pis = getAssets().open("config/settings.plist");
        OBXMLManager xmlManager = new OBXMLManager();
        config = (Map<String,Object>)xmlManager.parsePlist(pis);

        float h = getResources().getDisplayMetrics().heightPixels;
        float w = getResources().getDisplayMetrics().widthPixels;
        if (h > w)
        {
            float temp = w;
            w = h;
            h = temp;
        }
        float graphicScale = h / 768;
        config.put(CONFIG_GRAPHIC_SCALE,graphicScale);

        config.put(CONFIG_DEFAULT_LANGUAGE, configStringForKey(CONFIG_LANGUAGE));
        config.put(CONFIG_LEFT_BUTTON_POS, new PointF(0.0677f,0.075f));
        config.put(CONFIG_RIGHT_BUTTON_POS, new PointF(0.9323f,0.075f));
        List<String> cols = (List<String>) config.get(CONFIG_COLOURS);
        ArrayList<Integer> newcols =  new ArrayList<Integer>();
        for (String s : cols)
        {
            int col = OB_utils.colorFromRGBString(s);
            newcols.add(Integer.valueOf(col));
        }
        config.put(CONFIG_COLOURS,newcols);
        cols = (List<String>) config.get(CONFIG_SKINCOLOURS);
        newcols =  new ArrayList<Integer>();
        for (String s : cols)
        {
            int col = OB_utils.colorFromRGBString(s);
            newcols.add(Integer.valueOf(col));
        }
        config.put(CONFIG_SKINCOLOURS,newcols);
        Object clothcolour = config.get(CONFIG_CLOTHCOLOUR);
        if (clothcolour != null && clothcolour instanceof String)
        {
            int col = OB_utils.colorFromRGBString((String)clothcolour);
            config.put(CONFIG_CLOTHCOLOUR, Integer.valueOf(col));
        }
        updateConfigPaths((String)config.get(CONFIG_APP_CODE),true);
    }

    void retrieveUsers()
    {
    }

    public float applyGraphicScale(float val)
    {
        return val * configFloatForKey(CONFIG_GRAPHIC_SCALE);
    }

}

