package org.onebillion.xprz.utils;


public class OB_MutFloat
{
    public float value;
    public OB_MutFloat(float f)
    {
        value = f;
    }
}
