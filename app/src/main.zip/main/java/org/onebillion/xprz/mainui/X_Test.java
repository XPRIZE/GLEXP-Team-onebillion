package org.onebillion.xprz.mainui;

import android.graphics.PointF;
import android.os.AsyncTask;
import android.view.View;

import java.util.Collections;

/**
 * Created by alan on 20/12/15.
 */
public class X_Test extends XPRZ_SectionController
{
    public X_Test()
    {
        super();
    }
    public void prepare()
    {
        super.prepare();
        if (parameters.get("hard") != null && parameters.get("hard").equals("false"))
            view.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        loadFingers();
        loadEvent("mastera");
        events = Collections.singletonList("1a");

        doVisual(currentEvent());
    }
    @Override
    public void touchDownAtPoint(PointF pt,OBView v)
    {
        new AsyncTask<Void, Void, Void>()
        {
            protected Void doInBackground(Void... params)
            {
                nextScene();
                return null;
            }
        }.execute();


    }

}
