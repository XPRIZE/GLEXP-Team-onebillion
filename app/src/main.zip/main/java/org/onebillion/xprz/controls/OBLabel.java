package org.onebillion.xprz.controls;

import android.graphics.Color;
import android.graphics.Typeface;

/**
 * Created by alan on 12/12/15.
 */
public class OBLabel extends OBControl
{
    public OBLabel()
    {
        super();

    }

    public OBLabel(String s,Typeface tf,float sz)
    {
        this();
        layer = new OBTextDrawable(tf,sz, Color.BLACK,s);
        ((OBTextDrawable)layer).sizeToBoundingBox();
    }

    public void setColour(int col)
    {
        ((OBTextDrawable)layer).colour = col;
        invalidate();
    }

    public void setString(String s)
    {
        OBTextDrawable tl = (OBTextDrawable)layer;
        if (! tl.text.equals(s))
        {
            invalidate();
            synchronized (this)
            {
                tl.text = s;
            }
            invalidate();
        }
    }
}
