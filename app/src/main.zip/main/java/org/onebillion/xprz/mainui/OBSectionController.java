package org.onebillion.xprz.mainui;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Looper;
import android.os.SystemClock;

import org.onebillion.xprz.controls.OBControl;
import org.onebillion.xprz.controls.OBGroup;
import org.onebillion.xprz.controls.OBImage;
import org.onebillion.xprz.controls.OBPath;
import org.onebillion.xprz.controls.OBStroke;
import org.onebillion.xprz.utils.OBAnim;
import org.onebillion.xprz.utils.OBAnimationGroup;
import org.onebillion.xprz.utils.OBAudioManager;
import org.onebillion.xprz.utils.OBImageManager;
import org.onebillion.xprz.utils.OBRunnableSyncUI;
import org.onebillion.xprz.utils.OBRunnableUI;
import org.onebillion.xprz.utils.OBXMLManager;
import org.onebillion.xprz.utils.OBXMLNode;
import org.onebillion.xprz.utils.OB_Maths;
import org.onebillion.xprz.utils.OB_MutBoolean;
import org.onebillion.xprz.utils.OB_utils;
import org.onebillion.xprz.utils.UGradient;
import org.onebillion.xprz.utils.URadialGradient;

public class OBSectionController extends OBViewController
{
    public static final int STATUS_NIL = 0,
            STATUS_AWAITING_CLICK = 1,
            STATUS_AWAITING_CLICK2 = 2,
            STATUS_DRAGGING = 3,
            STATUS_CHECKING = 4,
            STATUS_DOING_DEMO = 5,
            STATUS_WAITING_FOR_TRACE = 6,
            STATUS_TRACING = 7,
            STATUS_WAITING_FOR_POT_CLICK = 8,
            STATUS_WAITING_FOR_OBJ_CLICK = 9,
            STATUS_WAITING_FOR_OBJ_COLOUR_CLICK = 10,
            STATUS_WAITING_FOR_BUTTON_CLICK = 11,
            STATUS_WAITING_FOR_RESUME = 12,
            STATUS_WAITING_FOR_DRAG = 13,
            STATUS_AWAITING_ARROW_CLICK = 14,
            STATUS_EXITING = 15,
            STATUS_SHOWING_POP_UP = 16,
            STATUS_EDITING = 17,
            STATUS_IDLE = 18,
            STATUS_BUSY = 19;
    public static final int POINTER_ZPOS = 1000;
    public static final int POINTER_BOTLEFT = 0,
            POINTER_BOTRIGHT = 1,
            POINTER_LEFT = 2,
            POINTER_MIDDLE = 3,
            POINTER_RIGHT =4;
    public List<OBControl> objects,nonobjects,attachedControls,buttons,sortedAttachedControls;
    public List<String>events;
    public Map<String,Object>audioScenes,eventsDict;
    public Map<String,OBControl> miscObjects,objectDict;
    public Map<String,String>eventAttributes,parameters;
    int eventIndex,replayAudioIndex,theStatus,theMoveSpeed;
    OBControl thePointer,tick;
    List<Object> _replayAudio;
    long audioQueueToken,sequenceToken,statusTime;
    public int targetNo,currNo;
    public Object params;
    public OBControl target;
    public boolean _aborting,sortedAttachedControlsValid;
    Lock sequenceLock;

    public OBSectionController(Activity a)
    {
        super(a);
        objects = new ArrayList<OBControl>();
        buttons = new ArrayList<OBControl>();
        nonobjects = new ArrayList<OBControl>();
        attachedControls = new ArrayList<OBControl>();
        sortedAttachedControls = new ArrayList<OBControl>();
        events = new ArrayList<String>();
        eventAttributes = new HashMap<String, String>();
        objectDict = new HashMap<String, OBControl>();
        miscObjects = new HashMap<String, OBControl>();
        _aborting = false;
        sequenceLock = new ReentrantLock();
        sortedAttachedControlsValid = true;
    }
    public static Map<String,Object>dictForObject(OBXMLNode e)
    {
        Map<String,Object> objectDict = new HashMap<String,Object>();
        Map<String,String> attrs = e.attributes;
        if (attrs != null)
        {
            objectDict.put("attrs",attrs);
            String objid = attrs.get("id");
            if (objid != null)
                objectDict.put("id",objid);
        }
        List<OBXMLNode> chs = e.children;
        if (chs.size() > 0)
        {
            List<Map<String,Object>> children = new ArrayList<Map<String,Object>>();
            for (OBXMLNode ch:chs)
                children.add(dictForObject(ch));
            objectDict.put("children",children);
        }
        objectDict.put("nodetype",e.nodeName);
        if (e.contents != null)
            objectDict.put("contents",e.contents);
        return objectDict;
    }

    public Map<String,Object> loadXML(String xmlPath)
    {
        Map<String,Object> eventsDict = new HashMap<>();
        OBXMLNode xmlNode = null;
        try
        {
            if (xmlPath != null)
            {
                Map<String,Object> mstr = null;
                OBXMLManager xmlManager = new OBXMLManager();
                List<OBXMLNode> xl = xmlManager.parseFile(MainActivity.mainActivity.getAssets().open(xmlPath));
                xmlNode = xl.get(0);
                List<OBXMLNode> xmlevents = xmlNode.childrenOfType("event");
                for(OBXMLNode xmlevent:xmlevents)
                {
                    String key = xmlevent.attributeStringValue("id");
                    if (key == null)
                        key = "";
                    Map<String,Object> eventDict = new HashMap<>();
                    eventDict.put("attrs",xmlevent.attributes);
                    List<Object> objs = new ArrayList<>();
                    Map<String,Object> objectsDict = new HashMap<>();
                    for (OBXMLNode e:xmlevent.children)
                    {
                        Map<String,Object> objectDict = dictForObject(e);
                        String objid = (String)objectDict.get("id");
                        if (objid != null)
                            objectsDict.put(objid,objectDict);
                        objs.add(objectDict);
                    }
                    eventDict.put("objects",objs);
                    eventDict.put("objectsdict",objectsDict);
                    eventsDict.put(key,eventDict);
                    if (mstr == null)
                        mstr = eventDict;
                }
                if (eventsDict.get("master") == null)
                    eventsDict.put("master",mstr);
            }
        }
        catch (Exception e)
        {

        }
        return eventsDict;
    }

    public void loadAudioXML(String xmlPath)
    {
        try
        {
            audioScenes = OBAudioManager.loadAudioXML(MainActivity.mainActivity.getAssets().open(xmlPath));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public void viewWillAppear(Boolean animated)
    {
        _aborting = false;
    }

    static Map<String,Object> Config()
    {
        return MainActivity.mainActivity.Config();
    }
    public String getConfigPath(String cfgName)
    {
        for (String path : (List<String>)Config().get(MainActivity.CONFIG_CONFIG_SEARCH_PATH))
        {
            String fullpath = OB_utils.stringByAppendingPathComponent(path, cfgName);
            if (OB_utils.fileExistsAtPath(fullpath))
                return fullpath;
        }
        return null;
    }

    public String getLocalPath(String fileName)
    {
        for (String path : (List<String>)Config().get(MainActivity.CONFIG_AUDIO_SEARCH_PATH))
        {
            String fullpath = OB_utils.stringByAppendingPathComponent(path,fileName);
            if (OB_utils.fileExistsAtPath(fullpath))
                return fullpath;
        }
        return null;
    }


    public void prepare()
    {
        super.prepare();
        view.setBackgroundColor(Color.WHITE);
        theMoveSpeed = bounds().width();
        inited = true;
        processParams();
        eventsDict = loadXML(getConfigPath(sectionName()+".xml"));
        loadAudioXML(getConfigPath(sectionName()+"audio.xml"));
    }

    public void start()
    {

    }

    public OBPath loadPath(Map<String,Object>attrs,RectF parentRect,float graphicScale,Map<String,Object>defs)
    {
        String pathString = (String)attrs.get("d");
        Path p = OBPath.pathFromSVGPath(pathString);
        Matrix t = new Matrix();
        t.preTranslate(parentRect.left, parentRect.top);
        t.preScale(parentRect.width(), parentRect.height());
        p.transform(t);
        OBPath path = makeShape(attrs,p,graphicScale,defs);
        return path;
    }

    public OBPath makeShape(Map<String,Object>attrs,Path p,float graphicScale,Map<String,Object>defs)
    {
        OBPath im = null;
        String fillstr = (String)attrs.get("fill");
        if (fillstr != null && fillstr.startsWith("url("))
        {
            Map<String,Object> settings = new HashMap<String,Object>();
            settings.putAll(attrs);
            settings.put("defs",defs);/*
            im = [[ClassForSettings(settings)alloc]init];
            String url = fillstr.substring(5,fillstr.length());
            Object obj = defs.get(url);
            if (obj)
            {
                if ([obj isKindOfClass:[OBPattern class]])
                {
                    ((OBPatternPath*)im).pattern = obj;
                    [((OBPatternPath*)im).patternLayer setNeedsDisplay];
                }
                else if (UGradient.class.isInstance(obj))
            {
                [((OBGradientPath*)im)takeValuesFrom:obj];
            }
            else if ([obj isKindOfClass:[URadialGradient class]])
                {
                    [((OBRadialGradientPath*)im)takeValuesFrom:obj];
                }
                if (p != null)
                    im.setPath(p);
                else
                {
                    if ([im isKindOfClass:[OBGradientPath class]])
                    ((OBGradientPath*)im).gradientLayer.mask = nil;
                }
            }*/
        }
        else
        {
            int fill = 0;
            if (fillstr != null)
            {
                fill = OB_utils.svgColorFromRGBString(fillstr);
                if (attrs.get("fillopacity") != null)
                {
                    float fo = Float.parseFloat((String)attrs.get("fillopacity"));
                    fill = Color.argb((int)(fo * 255),Color.red(fill),Color.green(fill),Color.blue(fill));
                }
            }
            if (p != null)
            {
                im = new OBPath(null);
                im.setPath(p);
                im.sizeToBoundingBox();
                im.setFillColor(fill);
            }
            else
            {
                im.backgroundColor = fill;
            }
        }
        return im;
    }

    static float floatOrZero(Map<String,Object>attrs,String s)
    {
        if (attrs.get(s) != null)
            return Float.parseFloat((String)attrs.get(s));
        return 0;
    }

    public OBControl loadShape(Map<String,Object>attrs,String nodeType,float graphicScale,RectF r,Map<String,Object>defs)
    {
        OBControl im = null;
        float x = floatOrZero(attrs, "x");
        float y = floatOrZero(attrs, "y");
        float w = floatOrZero(attrs, "width");
        float h = floatOrZero(attrs, "height");
        RectF f = OB_Maths.denormaliseRect(new RectF(x, y, x + w, y + h), r);
        String s = (String)attrs.get("widthtracksheight");
        if (s != null && s.equals("true"))
        {
            float origheight = floatOrZero(attrs,"pxheight");
            if (origheight > 0)
            {
                float ratio = f.height() / origheight;
                float newWidth = floatOrZero(attrs,"pxwidth") * ratio;
                float diff = newWidth - f.width();
                f.left -= diff / 2;
                f.right = f.left + newWidth;
            }
        }
        else
        {
            s = (String)attrs.get("heighttrackswidth");
            if (s != null && s.equals("true"))
            {
                float origwidth = floatOrZero(attrs, "pxwidth");
                if (origwidth > 0)
                {
                    float ratio = f.width() / origwidth;
                    float newHeight = floatOrZero(attrs, "pxheight") * ratio;
                    float diff = newHeight - f.height();
                    f.top -= diff / 2;
                    f.bottom = f.top + newHeight;
                }
            }
        }
        String fit = (String)attrs.get("fit");
        if (fit != null)
        {
            String[] arr = fit.split(",");
            Set<String>fitattrs = new HashSet<String>();
            fitattrs.addAll(Arrays.asList(arr));
            RectF vf = new RectF(bounds());
            if (fitattrs.contains("fitwidth"))
            {
                f.left = 0;
                f.right = vf.width();
            }
            if (fitattrs.contains("fitheight"))
            {
                f.top = 0;
                f.bottom = vf.height();
            }
            if (fitattrs.contains("stretchtotop"))
            {
                f.top = 0;
            }
            if (fitattrs.contains("stretchtobottom"))
            {
                f.bottom = vf.bottom;
            }
        }
        Path p = null;
        RectF b = new RectF(f);
        b.bottom -= b.top;
        b.top = 0;
        b.right -= b.left;
        b.left = 0;
        if (nodeType.equals("circle"))
        {
            p = new Path();
            p.addOval(b,Path.Direction.CCW);
        }
        else
        {
            if (attrs.get("cornerradius") != null)
            {
                float cr = floatOrZero(attrs,"cornerradius");
                cr *= b.height();
                p = new Path();
                p.addRoundRect(b,cr,cr,Path.Direction.CCW);
            }
            else
            {
                p = new Path();
                p.addRect(b,Path.Direction.CCW);
            }
        }
        im = makeShape(attrs,p,graphicScale,defs);
        im.setPosition(f.centerX(),f.centerY());
        return im;
    }

    static List<List<Object>> gradientStopsFromArray(List<Map<String,Object>> children)
    {
        int col = Color.BLACK;
        List<List<Object>> elements = new ArrayList<>();
        for (Map<String,Object> stopdict : children)
        {
            Map<String,String> stopattrs = (Map<String,String>)stopdict.get("attrs");
            String s = stopattrs.get("offset");
            float stopf = OB_utils.floatOrPercentage(s);
            s = stopattrs.get("stop-color");
            if (s != null)
                col = OB_utils.colorFromRGBString(s);
            float alpha = 1;
            s = stopattrs.get("stop-opacity");
            if (s != null)
            {
                alpha = Float.parseFloat(s);
                col = Color.argb((int) (alpha * 255), Color.red(col), Color.green(col), Color.blue(col));
            }
            List<Object> tmpl = new ArrayList<>();
            tmpl.add(col);
            tmpl.add(stopf);
            elements.add(tmpl);
        }
        return elements;
    }

    public static UGradient gradientFromAttributes(Map<String,Object> attrs)
    {
        UGradient grad = new UGradient();
        String s;
        if ((s = (String)attrs.get("x1")) != null)
            grad.x1 = OB_utils.floatOrPercentage(s);
        if ((s = (String)attrs.get("x2")) != null)
            grad.x2 = OB_utils.floatOrPercentage(s);
        if ((s = (String)attrs.get("y1")) != null)
            grad.y1 = OB_utils.floatOrPercentage(s);
        if ((s = (String)
                attrs.get("y2")) != null)
            grad.y2 = OB_utils.floatOrPercentage(s);
        grad.stops = gradientStopsFromArray((List<Map<String,Object>>)(attrs.get("children")));
        return grad;
    }

    public static URadialGradient radialGradientFromAttributes(Map<String,Object> attrs)
    {
        URadialGradient grad = new URadialGradient();
        String s;
        if ((s = (String)attrs.get("cx")) != null)
            grad.cx = OB_utils.floatOrPercentage(s);
        if ((s = (String)attrs.get("fx")) != null)
            grad.fx = OB_utils.floatOrPercentage(s);
        if ((s = (String)attrs.get("cy")) != null)
            grad.cy = OB_utils.floatOrPercentage(s);
        if ((s = (String)attrs.get("fy")) != null)
            grad.fy = OB_utils.floatOrPercentage(s);
        if ((s = (String)attrs.get("r")) != null)
            grad.r = OB_utils.floatOrPercentage(s);
        grad.stops = gradientStopsFromArray((List<Map<String,Object>>)(attrs.get("children")));
        return grad;
    }

    public static OBControl objectWithMaxZpos(List<OBControl> arr)
    {
        OBControl maxobj = null;
        float maxzpos = -100;
        for (OBControl c : arr)
            if (c.zPosition > maxzpos)
            {
                maxobj = c;
                maxzpos = c.zPosition;
            }
        return maxobj;
    }

    public Object loadImageFromDictionary(Map<String,Object> image,float graphicScale,Map<String,Object>defs)
    {
        boolean scalable = true;
        Map<String,Object> attrs = (Map<String,Object>)image.get("attrs");
        RectF r = new RectF(bounds());
        String imageID = (String)attrs.get("id");
        String par = (String)attrs.get("parent");
        if (par != null)
        {
            OBControl c = objectDict.get(par);
            if (c == null)
                System.out.println("No parent object " + par + "for" + imageID);
            else
            {
                if (c.parent != null)
                    r = convertRectFromControl(c.bounds(),c);
                else
                    r = c.frame();
            }
        }
        String posstr = (String)attrs.get("pos");
        PointF pos = OB_utils.pointFromString(posstr);
        OBControl im = null;
        String nodeType = (String)image.get("nodetype");
        if (nodeType.equals("image"))
            im = loadImageWithName((String)attrs.get("src"),pos,r,false);
        else if (nodeType.equals("vector"))
        {
            im = loadVectorWithName((String)attrs.get("src"),pos,r,false);
            int skinOffset = 0;
            if (attrs.get("skinoffset") != null)
                skinOffset = Integer.parseInt((String)attrs.get("skinoffset"));
            int skincol = OB_utils.SkinColour(OB_utils.SkinColourIndex() + skinOffset);
            ((OBGroup)im).substituteFillForAllMembers("skin.*", skincol);
            Integer cc = (Integer)Config().get(MainActivity.CONFIG_CLOTHCOLOUR);
            if (cc != null)
            {
                int clothcol = cc;
                ((OBGroup)im).substituteFillForAllMembers("cloth.*",clothcol);
            }
            if (attrs.get("fill") != null)
            {
                int col = OB_utils.colorFromRGBString((String)attrs.get("fill"));
                ((OBGroup)im).substituteFillForAllMembers("col.*", col);
            }
        }
        else if (nodeType.equals("path"))
        {
            scalable = false;
            im = loadPath(attrs,r,graphicScale,defs);
        }
        else if (nodeType.equals("linearGradient"))
        {
            Map<String,Object> d = new HashMap<String, Object>();
            d.putAll(attrs);
            return gradientFromAttributes(d);
        }
        else if (nodeType.equals("radialGradient"))
        {
            Map<String,Object> d = new HashMap<String, Object>();
            d.putAll(attrs);
            return radialGradientFromAttributes(d);
        }
        else if (nodeType.equals("group"))
        {
            scalable = false;
            List<Map<String,Object>>chs = (List<Map<String,Object>>)image.get("Children");
            if (chs.size() > 0)
            {
                List<OBControl> objs = new ArrayList<OBControl>();
                for (Map<String,Object> d : chs)
                {
                    Object o = loadImageFromDictionary(d,graphicScale,defs);
                    Map<String,Object> chattrs = (Map<String,Object>)d.get("attrs");
                    String objID = (String)chattrs.get("id");
                    if (OBControl.class.isInstance(o))
                    {
                        OBControl ch = (OBControl)o;
                        objs.add(ch);
                        if (objID != null)
                        {
                            objectDict.put(objID,ch);
                            ch.setProperty("name",objID);
                        }
                    }
                    else
                        defs.put(objID,o);
                }
                OBGroup grp = new OBGroup(objs);
                grp.buildObjectDict();
                im = grp;
                if (attrs.get("hasmask") != null)
                {
                    String hm = (String)attrs.get("hasmask");
                    if (hm.equals("true"))
                    {
                        OBControl mask = objectWithMaxZpos(grp.members);
                        im.setMaskControl(mask);
                    }
                }
            }
            float gx=1,gy=1;
            if (attrs.get("scalex") != null)
            {
                gx = floatOrZero(attrs,"scalex");
                gy = gx;
            }
            if (attrs.get("scaley") != null)
            {
                gy = floatOrZero(attrs,"scaley");
            }
            if (!(gx == 1 && gy == 1))
            {
                im.setScaleX(gx);
                im.setScaleY(gy);
            }
            if (attrs.get("fill") != null)
            {
                int col = OB_utils.colorFromRGBString((String)attrs.get("fill"));
                ((OBGroup)im).substituteFillForAllMembers("col.*",col);
            }
        }
        else if (nodeType.equals("text"))
        {
            scalable = false;
            OBPath path = (OBPath)loadShape(attrs,"rectangle",graphicScale,r,defs);
            path.sizeToBoundingBox();
            RectF b = path.bounds();
            List<OBControl> mems = Arrays.asList((OBControl) path);
            OBGroup grp = new OBGroup(mems);
            List<Map<String,Object>> chs = (List<Map<String,Object>>)image.get("children");
            for (Map<String,Object> d : chs)
            {
                // // TODO: 28/11/15
            }
            grp.buildObjectDict();
            im = grp;
        }
        else if (nodeType.equals("rectangle"))
        {
            scalable = false;
            im = loadShape(attrs,nodeType,graphicScale,r,defs);
        }
        else if (nodeType.equals("circle"))
        {
            scalable = false;
            im = loadShape(attrs,nodeType,graphicScale,r,defs);
        }
        if (im != null)
        {
            float scx = 1,scy = 1,shadScale = 1;
            if (scalable)
            {
                scx = scy = graphicScale;
                if (attrs.get("scalex") != null)
                {
                    scx = floatOrZero(attrs,"scalex") * graphicScale;
                    scy = scx;
                }
                if (attrs.get("scaley") != null)
                {
                    scy = floatOrZero(attrs,"scaley") * graphicScale;
                }
                if (!(scx == 1 && scy == 1))
                {
                    im.setScaleX(scx);
                    im.setScaleY(scy);
                }

            }
            if (attrs.get("rotation") != null)
            {
                float rt = floatOrZero(attrs,"rotation");
                im.setRotation((float)Math.toRadians((double)-rt));
            }
            if (nodeType.equals("vector"))
            {
                OBControl anchor = (OBControl)((OBGroup)im).objectDict.get("anchor");
                if (anchor != null)
                {
                    PointF pt = im.convertPointFromControl(anchor.position(),anchor.parent);
                    PointF rpt = OB_Maths.relativePointInRectForLocation(pt, im.bounds());
                    im.setAnchorPoint(rpt);
                }
            }
            if (attrs.get("anchor") != null && !nodeType.equals("rectangle"))
            {
                PointF anc = OB_utils.pointFromString((String)attrs.get("anchor"));
                PointF destPoint = OB_Maths.locationForRect(anc, im.frame());
                PointF vec = OB_Maths.DiffPoints(im.position(), destPoint);
                PointF newPoint = OB_Maths.AddPoints(im.position(), vec);
                im.setPosition(newPoint);
            }
            if (attrs.get("stroke") != null)
            {
                OBStroke str = new OBStroke(attrs,true);
                im.stroke = str;
            }
            if (attrs.get("opacity") != null)
            {
                im.setOpacity(floatOrZero(attrs,"opacity"));
            }
            if (attrs.get("shadowcolour") != null)
            {
                int col = OB_utils.colorFromRGBString((String)attrs.get("shadowcolour"));
                float ratio = Math.abs(1 / shadScale);
                if (!scalable)
                    ratio = graphicScale;
                float opacity = 1,xoff = 0,yoff = 0,rad = 3;
                if (attrs.get("shadowopacity") != null)
                    opacity = Float.parseFloat((String)attrs.get("shadowopacity"));
                if (attrs.get("shadowradius") != null)
                    rad = Float.parseFloat((String)attrs.get("shadowradius"));
                if (attrs.get("shadowxoffset") != null)
                    xoff = Float.parseFloat((String)attrs.get("shadowxoffset"));
                if (attrs.get("shadowyoffset") != null)
                    yoff = Float.parseFloat((String)attrs.get("shadowyoffset"));
                im.setShadow(rad,opacity,xoff,yoff,col);
            }
            im.zPosition = (floatOrZero(attrs,"zpos"));
            if ((attrs.get("hidden") != null && attrs.get("hidden").equals("true")) || (attrs.get("display") != null && attrs.get("display").equals("none")))
                im.hide();
            im.setProperty("attrs",attrs);
        }
        return im;
    }

    public float graphicScale()
    {
     return (Float)(Config().get(MainActivity.mainActivity.CONFIG_GRAPHIC_SCALE));
    }

    public void loadEvent(String eventID)
    {
        float graphicScale = graphicScale();
        Map<String,Object>event = (Map<String,Object>)eventsDict.get(eventID);
        if (event == null)
            event = new HashMap<>();
        eventAttributes = (Map<String,String>)event.get("attrs");
        if (eventAttributes == null)
            eventAttributes = new HashMap<>();
        if (eventAttributes.get("colour") != null)
            view.setBackgroundColor(OB_utils.colorFromRGBString(eventAttributes.get("colour")));
        if (eventAttributes.get("gradienttop") != null)
        {
            int col1 = OB_utils.colorFromRGBString(eventAttributes.get("gradienttop"));
            int col2 = OB_utils.colorFromRGBString(eventAttributes.get("gradientbottom"));
            GradientDrawable gd = new GradientDrawable();
            int cols[] = new int[2];
            cols[0] = col1;
            cols[1] = col2;
            gd.setColors(cols);
            gd.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
            view.setBackground(gd);
        }
        Map<String,Object>defs = new HashMap<String,Object>();
        List<Map<String,Object>> imageList = (List<Map<String,Object>>)event.get("objects");
        if (imageList != null)
            for (Map<String,Object> image : imageList)
            {
                Object im = loadImageFromDictionary(image,graphicScale,defs);
                if (im != null)
                {
                    Map<String,Object> attrs = (Map<String,Object>)image.get("attrs");
                    String objID = (String)attrs.get("id");
                    if (OBControl.class.isInstance(im))
                    {
                        objectDict.put(objID,(OBControl)im);
                        attachControl((OBControl)im);
                    }
                    else
                        defs.put(objID,im);
                }
            }
    }

    public void processParams()
    {
        if (params != null)
        {
            if (String.class.isInstance(params))
            {
                Map<String,String> d = new HashMap<>();
                String components[] = ((String)params).split("/");
                for (int i = 0;i < components.length;i++)
                {
                    String pieces[] = components[i].split("=");
                    if (pieces.length == 1)
                        d.put((new Integer(i)).toString(),pieces[0]);
                    else if (pieces.length > 1)
                        d.put(pieces[0],pieces[1]);
                }
                parameters = d;
            }
        }
    }

    public String sectionName()
    {
        String par0 = ((String)params).split("/")[0];
        String parr[] = par0.split(";");
        return parr[0];
    }

    public String sectionAudioName()
    {
        String par0 = ((String)params).split("/")[0];
        String parr[] = par0.split(";");
        if (parr.length > 1)
            return parr[1];
        return parr[0];
    }
    public String currentEvent()
    {
        return events.get(eventIndex);
    }

    public boolean performSel(String root,String suffix)
    {
        String str = root+suffix;
        try
        {
            Method m = this.getClass().getMethod(str);
            m.invoke(this);
            return true;
        }
        catch (NoSuchMethodException e)
        {
        }
        catch (InvocationTargetException e)
        {
        }
        catch (IllegalAccessException e)
        {
        }
        return false;
    }

    public void doVisual(String scene)
    {
        if (!performSel("setScene",scene))
            setSceneXX(scene);
    }

    public void setSceneXX(String scene)
    {

    }

    public void doAudio(String scene) throws Exception
    {

    }

    public void fin()
    {

    }

    public void setScene(final String scene)
    {
        new OBRunnableSyncUI(){public void ex()
        {
            doVisual(scene);
        }}.run();

        try
        {
            doAudio(scene);
            switchStatus(scene);
        }
        catch (Exception exception)
        {
        }
    }

    public long switchStatus(String scene)
    {
        return 0;
    }

    public void nextScene()
    {
        if (++eventIndex >= events.size())
        {
            new AsyncTask<Void, Void, Void>()
            {
                @Override
                protected Void doInBackground(Void... params)
                {
                    fin();
                    return null;
                }
            }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void[]) null);
        }
        else
        {
            new AsyncTask<Void, Void, Void>()
            {
                @Override
                protected Void doInBackground(Void... params) {
                    setScene(events.get(eventIndex));
                    return null;
                }
            }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void[]) null);
        }
    }

    public void hideControls(String pattern)
    {
        for (OBControl c : filterControls(pattern))
            c.hide();
    }

    public void showControls(String pattern)
    {
        for (OBControl c : filterControls(pattern))
            c.show();
    }

    public void deleteControls(String pattern)
    {
        for (String s : filterControlsIDs(pattern))
        {
            OBControl c = objectDict.get(s);
            detachControl(c);
            objectDict.remove(s);
        }
    }

    public void attachControl(OBControl control)
    {
        attachedControls.add(control);
        control.controller = this;
        sortedAttachedControlsValid = false;
        RectF f = control.frame();
        invalidateView((int) f.left, (int) f.top, (int) f.right, (int) f.bottom);
    }

    public void detachControl(OBControl control)
    {
        RectF f = control.frame();
        attachedControls.remove(control);
        control.controller = null;
        invalidateView((int) f.left, (int) f.top, (int) f.right, (int) f.bottom);
        sortedAttachedControlsValid = false;
    }

    public List<String> filterControlsIDs(String pattern)
    {
        List<String> arr = new ArrayList<String>();
        Pattern p = Pattern.compile(pattern);
        for (String k : objectDict.keySet())
        {
            Matcher matcher = p.matcher(k);
            matcher.find();
            if (matcher.matches())
                arr.add(k);
        }
        return arr;
    }

    public List<OBControl> filterControls(String pattern)
    {
        List<OBControl> arr = new ArrayList<OBControl>();
        for (String name : filterControlsIDs(pattern))
            arr.add(objectDict.get(name));
        return arr;
    }

    public List<OBControl> sortedFilteredControls(String pattern)
    {
        List<String> arr = filterControlsIDs(pattern);
        Collections.sort(arr);
        List<OBControl> arr3 = new ArrayList<OBControl>();
        for (String k : arr)
            arr3.add(objectDict.get(k));
        return arr3;
    }

    public List<OBControl> zPositionSortedFilteredControls(String pattern)
    {
        List<String> arr = filterControlsIDs(pattern);
        Collections.sort(arr,new Comparator<String>(){
            @Override
            public int compare(String o1, String o2)
            {
                OBControl c1 = objectDict.get(o1);
                OBControl c2 = objectDict.get(o2);
                float z1 = c1.zPosition;
                float z2 = c2.zPosition;
                if (z1 < z2)
                    return -1;
                if (z1 > z2)
                    return 1;
                return 0;
            }
        });
        List<OBControl> carr = new ArrayList<OBControl>();
        for (String s : arr)
            carr.add(objectDict.get(s));
        return carr;
    }

    void populateSortedAttachedControls()
    {
        if (!sortedAttachedControlsValid)
        {
            sortedAttachedControls.clear();
            sortedAttachedControls.addAll(attachedControls);
            for (int i = 0;i < sortedAttachedControls.size();i++)
                sortedAttachedControls.get(i).tempSortInt = i;
            Collections.sort(sortedAttachedControls, new Comparator<OBControl>()
            {
                @Override
                public int compare(OBControl lhs, OBControl rhs)
                {
                    if (lhs.zPosition < rhs.zPosition)
                        return -1;
                    if (lhs.zPosition > rhs.zPosition)
                        return 1;
                    if (lhs.tempSortInt < rhs.tempSortInt)
                        return -1;
                    if (lhs.tempSortInt > rhs.tempSortInt)
                        return 1;
                    return 0;
                }
            });
            sortedAttachedControlsValid = true;
        }
    }
    public void drawControls(Canvas canvas)
    {
        Rect clipb = canvas.getClipBounds();
        populateSortedAttachedControls();
        for (OBControl control : sortedAttachedControls)
        {
            if (control.frame().intersects(clipb.left,clipb.top,clipb.right,clipb.bottom))
                control.draw(canvas);
        }
    }

    public OBImage loadImageWithName(String nm,PointF pt,RectF r,boolean attach)
    {
        OBImage im = OBImageManager.sharedImageManager().imageForName(nm);
        if (im != null)
        {
            PointF pos = OB_Maths.locationForRect(pt, r);
            im.setPosition(pos);
            if (attach)
                attachControl(im);
            return im;
        }
        return null;
    }

    public OBImage loadImageWithName(String nm,PointF pt,RectF r)
    {
        return loadImageWithName(nm, pt, r, true);
    }

    public OBGroup loadVectorWithName(String nm,PointF pt,RectF r,boolean attach)
    {
        OBGroup im = OBImageManager.sharedImageManager().vectorForName(nm);
        if (im != null)
        {
            PointF pos = OB_Maths.locationForRect(pt, r);
            im.setPosition(pos);
            if (attach)
                attachControl(im);
            return im;
        }
        return null;
    }

    public OBGroup loadVectorWithName(String nm,PointF pt,RectF r)
    {
        return loadVectorWithName(nm,pt,r,true);
    }

    public long setStatus(int st)
    {
        long sttime;
        synchronized(events)
        {
            theStatus = st;
            sttime = System.nanoTime();
            statusTime = sttime;
        }
        return sttime;
    }

    public Boolean statusChanged(long sttime)
    {
        return sttime != statusTime;
    }

    public int status()
    {
        return theStatus;
    }

    public void movePointerToPoint(PointF pt,float secs,boolean wait)
    {
        if (secs < 0)
        {
            float dist = OB_Maths.PointDistance(pt, thePointer.position);
            secs = dist / ((float) theMoveSpeed * Math.abs(secs));
        }
        if (Math.abs(pt.x) < 2.0 && Math.abs(pt.y) < 2.0)
            pt = OB_Maths.locationForRect(pt, bounds());
        OBAnimationGroup.runAnims(Arrays.asList(OBAnim.moveAnim(pt, thePointer)), secs, wait, OBAnim.ANIM_EASE_IN_EASE_OUT, this);
    }

    public void movePointerToPoint(PointF pt,float angle,float secs,boolean wait)
    {
        if (secs < 0)
        {
            float dist = OB_Maths.PointDistance(pt, thePointer.position);
            secs = dist / ((float) theMoveSpeed * Math.abs(secs));
        }
        if (Math.abs(pt.x) < 2.0 && Math.abs(pt.y) < 2.0)
            pt = OB_Maths.locationForRect(pt, bounds());
        List<OBAnim> anims = new ArrayList<OBAnim>();
        anims.add(OBAnim.moveAnim(pt, thePointer));
        anims.add(OBAnim.rotationAnim((float)Math.toRadians((double)angle),thePointer));
        OBAnimationGroup.runAnims(anims, secs, wait, OBAnim.ANIM_EASE_IN_EASE_OUT, this);
    }

    public void movePointerForwards(float distance,float secs)
    {
        float ang = thePointer.rotation;
        float x = (float)Math.sin((float)ang);
        float y = -(float)Math.cos((float) ang);
        float len = (float)Math.sqrt(x * x + y * y);
        float ratio = distance / len;
        x *= ratio;
        y *= ratio;
        PointF pos = new PointF(thePointer.position.x,thePointer.position.y);
        pos.x += x;
        pos.y += y;
        movePointerToPoint(pos, secs, true);
    }

    public void loadPointerStartPoint(PointF startPoint,PointF targetPoint)
    {
        if (thePointer == null)
        {
            OBGroup arm = MainActivity.mainActivity.armPointer();
            arm.zPosition = POINTER_ZPOS;
            float graphicScale = MainActivity.mainActivity.applyGraphicScale(1);
            arm.scaleX = arm.scaleY = graphicScale;
            thePointer = arm;
            attachControl(arm);
        }
        else
            thePointer.show();
        thePointer.position = startPoint;
        thePointer.pointAt(targetPoint);
        thePointer.frame();
        invalidateView((int) thePointer.frame.left, (int) thePointer.frame.top, (int) thePointer.frame.right, (int) thePointer.frame.bottom);
    }

    public void loadPointer(int orientation)
    {
        PointF startPoint,targetPoint;
        switch (orientation)
        {
            case POINTER_BOTLEFT:
                startPoint = new PointF(1, 0);
                targetPoint = new PointF(0, 1);
                break;
            case POINTER_BOTRIGHT:
                startPoint = new PointF(0, 0);
                targetPoint = new PointF(1, 1);
                break;
            case POINTER_LEFT:
                startPoint = new PointF(0.75f,1);
                targetPoint = new PointF(0,0);
                break;
            case POINTER_MIDDLE:
                startPoint = new PointF(0.5f, 1);
                targetPoint = new PointF(0.5f, 0);
                break;
            case POINTER_RIGHT:
                startPoint = new PointF(0.25f,1);
                targetPoint = new PointF(1, 0);
                break;
            default:
                startPoint = new PointF(0.5f, 1);
                targetPoint = new PointF(0.5f, 0);
        }
        startPoint = OB_Maths.locationForRect(startPoint, bounds());
        targetPoint = OB_Maths.locationForRect(targetPoint, bounds());
        loadPointerStartPoint(startPoint, targetPoint);

    }
    void _playAudio(String fileName)
    {
        if(Looper.myLooper() == Looper.getMainLooper())
            OBAudioManager.audioManager.startPlaying(fileName);
        else
        {
            if (fileName != null)
                fileName = new String(fileName);
            final String fn = fileName;
            new OBRunnableSyncUI(){public void ex()
            {
                _playAudio(fn);
            }
            }.run();
        }
    }

    long takeSequenceLockInterrupt(boolean interrupt)
    {
        long token = SystemClock.uptimeMillis();
        if (interrupt)
        {
            sequenceToken = token;
            playAudio(null);
            sequenceLock.lock();
        }
        else
        {
            sequenceLock.lock();
            sequenceToken = token;
        }
        return token;
    }
    void checkSequenceToken(long token) throws Exception
    {
        if (token != sequenceToken)
            throw new Exception("Sequence interrupted");
    }

    void playAudio(String fileName)
    {
        audioQueueToken = SystemClock.uptimeMillis();
        _playAudio(fileName);
    }

    void playBackgroundAudio(String fileName)
    {
        if(Looper.myLooper() == Looper.getMainLooper())
            OBAudioManager.audioManager.startPlaying(fileName,"1");
        else
        {
            final String fn = new String(fileName);
            new OBRunnableSyncUI(){public void ex()
            {
                playBackgroundAudio(fn);
            }
            }.run();
        }
    }

    void playAudioQueued(List<Object>qu,final boolean wait) throws Exception
    {
        Lock lock = null;
        Condition condition = null;
        if (wait)
        {
            lock = new ReentrantLock();
            condition = lock.newCondition();
        }
        long token;
        synchronized(this)
        {
            audioQueueToken = SystemClock.uptimeMillis();
            token = audioQueueToken;
        }
        final List<Object> fqu = qu;
        final long ftoken = token;
        final Lock flock = lock;
        final Condition fcondition = condition;
        final OB_MutBoolean fabort = new OB_MutBoolean(_aborting);
        new AsyncTask<Void,Void,Void>()
        {
            protected Void doInBackground(Void... params)
            {
                try
                {
                    for (Object obj : fqu)
                    {
                        if (ftoken != audioQueueToken)
                            break;
                        if (obj instanceof Integer)
                        {
                            Thread.sleep(((Integer)obj).intValue());
                        }
                        else
                        {
                            _playAudio((String)obj);
                            if (wait)
                                waitAudio();
                            else
                                waitAudioNoThrow();
                        }
                    }
                }
                catch (Exception exception)
                {
                    fabort.value = true;
                }
                if (flock != null)
                {
                    flock.lock();
                    fcondition.signalAll();
                    flock.unlock();
                }
                return null;
            }
        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Void[]) null);
        if (wait)
        {
            lock.lock();
            condition.await();
            lock.unlock();
        }
        if (fabort.value)
        {
            _aborting = true;
            throw new Exception("BackException");
        }
    }

    public void playAudioQueued(List<Object>qu) throws Exception
    {
        playAudioQueued(qu,false);
    }

    public void setReplayAudio(List<Object>arr)
    {
        if (arr != _replayAudio)
        {
            _replayAudio = arr;
        }
    }

    public void setReplayAudioScene(String scene,String event)
    {
        Map<String, List<String>> sc = (Map<String, List<String>>) audioScenes.get(scene);
        List<Object> arr = (List<Object>) (Object) sc.get(event); //yuk!
        setReplayAudio(arr);
    }

    public List<Object> emptyReplayAudio()
    {
        List<Object> arr = _replayAudio;
        _replayAudio = null;
        return arr;
    }

    void _replayAudio()
    {
        try
        {
            playAudioQueued(_replayAudio,true);
        }
        catch (Exception exception)
        {
        }
    }

    public void replayAudio()
    {
        if (_replayAudio != null)
        {
            setStatus(status());
            new AsyncTask<Void, Void, Void>()
            {
                protected Void doInBackground(Void... params)
                {
                    _replayAudio();
                    return null;
                }
            }.execute();
        }
    }

    public void exitEvent()
    {
        setStatus(STATUS_EXITING);
        playAudio(null);
        _aborting = true;
        new OBRunnableUI(){public void ex()
        {
            MainActivity.mainViewController.popViewController();
        }
        }.run();
    }

    public void prevPage()
    {

    }

    public void nextPage()
    {

    }

    void waitAudioNoThrow()
    {
        OBAudioManager.audioManager.waitAudio();
    }

    public boolean waitForAudio()
    {
        if (_aborting)
            return false;
        OBAudioManager.audioManager.waitAudio();
        return !_aborting;
    }

    public void waitAudio() throws Exception
    {
        if (_aborting)
            throw new Exception("BackException");
        OBAudioManager.audioManager.waitAudio();
        if (_aborting)
            throw new Exception("BackException");
    }

    public void waitAudioAndCheck(long stTime) throws Exception
    {
        if (!statusChanged(stTime))
            waitAudio();
        if (statusChanged(stTime))
            throw new Exception("BackException");
    }

    void _wait(double secs)
    {
        try
        {
            Thread.sleep((long)(secs * 1000));
        }
        catch (InterruptedException e)
        {
        }
    }
    public void waitForSecsNoThrow(double secs)
    {
        if (!_aborting)
            _wait(secs);
    }

    public void waitForSecs(double secs) throws Exception
    {
        if (!_aborting)
            _wait(secs);
        if (_aborting)
            throw new Exception("BackException");
    }

    public void displayTick() throws Exception
    {
        new OBRunnableSyncUI(){public void ex()
        {
            if (tick == null)
            {
                tick = loadVectorWithName("tick",new PointF(0.5f,0.5f),new RectF(bounds()),false);
                tick.setScale(graphicScale());
                tick.zPosition = 100;
            }
            attachControl(tick);
        }
        }.run();
        playAudio("ting");
        waitForSecs(1);
        new OBRunnableSyncUI(){public void ex()
        {
            invalidateControl(tick);
            detachControl(tick);
        }
        }.run();
    }

    public void invalidateControl(OBControl c)
    {
        RectF f = c.frame();
        invalidateView((int) (Math.floor((double) f.left)), (int) (Math.floor((double) f.top)),
                (int) (Math.floor((double) f.right)), (int) (Math.floor((double) f.bottom)));
    }


    public int buttonFlags()
    {
        return OBMainViewController.SHOW_TOP_LEFT_BUTTON|OBMainViewController.SHOW_TOP_RIGHT_BUTTON;
    }

    public PointF convertPointFromControl(PointF pt,OBControl c)
    {
        return c.convertPointToControl(pt, null);
    }

    public PointF convertPointToControl(PointF pt,OBControl c)
    {
        return c.convertPointFromControl(pt, null);
    }
    public RectF convertRectFromControl(RectF r,OBControl c)
    {
        return c.convertRectToControl(r, null);
    }

    public RectF convertRectToControl(RectF r,OBControl c)
    {
        return c.convertRectFromControl(r, null);
    }

    public List<OBAnim> animsForMoveToPoint(List<OBControl> objs,PointF pos)
    {
        OBControl obj = objs.get(0);
        PointF currPos = obj.position;
        PointF delta = OB_Maths.DiffPoints(pos, currPos);
        List<OBAnim> anims = new ArrayList<>();
        for (OBControl o : objs)
        {
            PointF opos = o.position;
            OBAnim anim = OBAnim.moveAnim(OB_Maths.AddPoints(opos, delta), o);
            anims.add(anim);
        }
        return anims;
    }

    public void moveObjects(List<OBControl>objs,PointF pos, float duration,int timingFunction)
    {
        if (duration < 0)
        {
            OBControl c = objs.get(0);
            duration = OB_utils.durationForPointDist(c.position, pos, theMoveSpeed);
        }
        OBAnimationGroup.runAnims(animsForMoveToPoint(objs,pos),duration,true,timingFunction,this);
    }

}

