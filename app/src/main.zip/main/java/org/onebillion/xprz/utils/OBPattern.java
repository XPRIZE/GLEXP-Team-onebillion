package org.onebillion.xprz.utils;

import android.graphics.Matrix;
import android.graphics.RectF;

import org.onebillion.xprz.controls.OBControl;

/**
 * Created by alan on 13/12/15.
 */
public class OBPattern
{
    public static int PAR_NONE = 0,
            PAR_SLICE = 1,
            PAR_MEET = 2,
            PAR_ALIGN_MIN=0,
            PAR_ALIGN_MID = 1,
            PAR_ALIGN_MAX = 2;
    public OBControl patternContents;
    public float x,y,patternWidth,patternHeight;
    public Matrix transform;
    public RectF viewBox;
    public boolean useBboxUnitsForPatternUnits,useBboxUnitsForPatternContentUnits,par_slice;
    public int preserveAspectRatio,xAlign,yAlign;

    public OBPattern()
    {
        super();
        useBboxUnitsForPatternUnits = false;
        useBboxUnitsForPatternContentUnits = true;
        transform = new Matrix();
    }

    public Object clone()
    {
        try
        {
            return super.clone();
        }
        catch (CloneNotSupportedException e)
        {
            e.printStackTrace();
        }
        return null;
    }
}
