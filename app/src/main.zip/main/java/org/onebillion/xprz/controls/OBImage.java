package org.onebillion.xprz.controls;

import android.graphics.drawable.Drawable;

public class OBImage extends OBControl
{
    public OBImage(Drawable d)
    {
        super();
        layer = d;
    }
}
