package org.onebillion.xprz.utils;


public class OB_MutInt
{
    public int value;
    public OB_MutInt(int st)
    {
        value = st;
    }
}
