package org.onebillion.xprz.utils;

/**
 * Created by alan on 16/12/15.
 */
public class OB_MutBoolean
{
    public boolean value;
    public OB_MutBoolean(boolean b)
    {
        value = b;
    }
}
